CSC467 Report

Jianning Yan (1000461715)
Wen Ying Zhang (1000404207)

Both team member contributed equally to all the parts of the labs.

Special Problems Encouter:
1. Understand the problem statement and the requirement of the lab
2. Understand how to compile and run the starter
3. Syntax of the lex file (missing a space between token and brace)
4. Getting the right regular expression for integer, float and identifier
5. Including all neccessary tokens (we missed a few at the beginning so the complier returned errors)
6. Order of the token (we put the identifier before keywords, so all the keywords were not recognized)

How to run the program:
make clean && make compiler467 && compiler467 -Tn [path-to-the-MiniGLSL-code]
